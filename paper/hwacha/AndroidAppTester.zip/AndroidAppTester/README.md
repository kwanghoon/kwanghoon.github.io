Copyright(C) 2015 Kwanghoon Choi All Rights Reserved

Android App Tester

1) GenTestsfromIntentSpec 
   - Generation of Tests from Each Intent Spec

2) UIforIntentSpec 
   - UI for Intent Spec
   - Automatic Generation of Intent Specs from APK

3) Batch mode and GUI-based/Text-based mode
   - Batch mode for multiple APK files
   - Single mode for single APK file


Contributed by
   - Kwanghoon Choi
   - Myung-Pil Ko 
   - Seungwhi Lee, and
   - Sung-Bin Yoon.
