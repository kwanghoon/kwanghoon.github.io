package kr_ac_yonsei_mobilesw_UI;

public enum ComponentMode {
	Activity, BroadcastReceiver, Service;
}
