package kr_ac_yonsei_mobilesw_UI;

public interface InterfaceWithExecution {
	public void appendTxt_testArtifacts(String str);
	public void done_testArtifacts(boolean fail);
	public void appendTxt_intentSpec(String str);
	public void done_intentSpec();
}
