
class MySet extends HashSet {
}


