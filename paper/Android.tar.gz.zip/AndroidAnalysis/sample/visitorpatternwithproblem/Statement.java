
public abstract class Statement extends AbstractNode {
	public Statement(final String aName) {
		super(aName);
	}

	/* To be implemented. */
}