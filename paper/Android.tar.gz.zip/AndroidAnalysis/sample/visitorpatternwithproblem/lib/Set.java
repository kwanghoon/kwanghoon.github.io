
public interface Set {
    public boolean add(Object e);
    public boolean remove(Object o);
    public Iterator iterator();
}

