public class StatementWhile extends StatementCompound {
	public StatementWhile(final String aName) {
		super(aName);
	}
}
