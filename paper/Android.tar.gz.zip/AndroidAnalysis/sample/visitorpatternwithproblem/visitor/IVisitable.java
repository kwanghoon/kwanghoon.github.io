
public interface IVisitable {
    void accept(final IVisitor aVisitor);
}
