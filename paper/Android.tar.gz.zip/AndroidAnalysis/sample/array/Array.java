
class Array {
    int[] y;

    Array (int[] z) { this.y = new int[100]; this.y = z; }

    String[] array_method() {
	this.y[10] = 123;

	return new String[10];
    }

    public static void main(String[] args) {
	String[][] s;
	char[] carr = new char[10];
	String z = "abc"; // new String("abc");
	s;

	String x = s[10][3];

        // x[1][2][3] = x[1][3][4];

        // return s[10];
    }
}