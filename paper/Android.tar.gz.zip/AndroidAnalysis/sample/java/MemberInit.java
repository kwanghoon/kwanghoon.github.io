
class Z {
}

public class MemberInit {
    HashSet h1 = new HashSet();
    HashSet h2 = new HashSet();

    void m() {
	Z z = new Z();
    }

    public static void main(String[] args) {
    }
}