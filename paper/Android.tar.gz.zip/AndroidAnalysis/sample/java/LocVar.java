
public class LocVar {
    public static void main(String[] args) {
	int x;

	x = 123;
    }
}

