Copyright(C) 2015 Kwanghoon Choi All Rights Reserved

Android App Tester

1) GenTestsfromIntentSpec 
   - Generation of Tests from Each Intent Spec

2) UIforIntentSpec 
   - UI for Intent Spec
   - Automatic Generation of Intent Specs from APK


Contributed by Myung-Pil Ko and Sung-Bin Yoon.
