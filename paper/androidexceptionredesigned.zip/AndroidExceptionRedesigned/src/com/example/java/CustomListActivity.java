package com.example.java;

public class CustomListActivity extends ExceptionListActivity {

	public void OnCreate() {
		super.OnCreate();
		System.out.println("CustomActivity.OnCreate");
	}

	public void OnDestroy() {
		super.OnDestroy();
		System.out.println("CustomActivity.OnDestroy");
	}

	public void OnClick() {
		super.OnClick();
		System.out.println("CustomActivity.OnClick");
	}

	public void OnItemClick() {
		super.OnItemClick();
		System.out.println("CustomActivity.OnItemClick");
	}

}
