package com.example.java;

public class ExceptionListActivity extends ListActivity {
	public void onCreate() {
		System.out.println("ExceptionListActivity.onCreate");
		this.OnCreate();
	}
	
	public void OnCreate() {
		super.onCreate();
		System.out.println("ExceptionListActivity.OnCreate");
	}
	
	public void onDestroy() {
		System.out.println("ExceptionListActivity.onDestroy");
		this.OnDestroy();
	}
	
	public void OnDestroy() {
		super.onDestroy();
		System.out.println("ExceptionListActivity.OnDestroy");
	}
	
	public void onClick() {
		System.out.println("ExceptionListActivity.onClick");
		this.OnClick();
	}
	
	public void OnClick() {
		super.onClick();
		System.out.println("ExceptionListActivity.OnClick");
	}

	public void onItemClick() {
		System.out.println("ExceptionListActivity.onItemClick");
		this.OnItemClick();
	}
	
	public void OnItemClick() {
		super.onItemClick();
		System.out.println("ExceptionListActivity.OnItemClick");
	}
}
