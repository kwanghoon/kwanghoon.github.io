package com.example.java.newdesign;

public interface IExceptionPreferenceActivity extends IPreferenceActivity, IExceptionActivity {
	public void OnPreferenceChanged();
}
