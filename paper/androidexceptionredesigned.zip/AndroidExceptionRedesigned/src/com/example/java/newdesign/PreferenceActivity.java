package com.example.java.newdesign;

public class PreferenceActivity extends Activity {
	public void onCreate() {
		super.onCreate();
		System.out.println("PreferenceActivity.onCreate");
	}
	public void onDestroy() {
		super.onDestroy();
		System.out.println("PreferenceActivity.onDestroy");
	}
	public void onClick() {
		super.onClick();
		System.out.println("PreferenceActivity.onClick");
	}
	
	public void onPreferenceChanged() {
		System.out.println("PreferenceActivity.onPreferenceChanged");
	}
	
	void setPreference() {
		System.out.println("PreferenceActivity.setPreference");
	}
}
