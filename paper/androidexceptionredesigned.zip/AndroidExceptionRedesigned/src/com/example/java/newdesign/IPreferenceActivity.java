package com.example.java.newdesign;

public interface IPreferenceActivity extends IActivity {
	public void onPreferenceChanged();
}
