package com.example.java.newdesign;

public class ExceptionPreferenceActivity extends PreferenceActivity 
	implements IExceptionPreferenceActivity {
	
	private IPreferenceActivity iPreferenceActivity;
	
	public ExceptionPreferenceActivity() {
		this.iPreferenceActivity = new ExceptionPreferenceActivityCore(this);
	}
	public void onCreate() {
		System.out.println("ExceptionPreferenceActivity.onCreate");
//		this.OnCreate();
		iPreferenceActivity.onCreate();
	}
	
	public void OnCreate() {
		super.onCreate();
		System.out.println("ExceptionPreferenceActivity.OnCreate");
	}
	
	public void onDestroy() {
		System.out.println("ExceptionPreferenceActivity.onDestroy");
//		this.OnDestroy();
		iPreferenceActivity.onDestroy();
	}
	
	public void OnDestroy() {
		super.onDestroy();
		System.out.println("ExceptionPreferenceActivity.OnDestroy");
	}
	
	public void onClick() {
		System.out.println("ExceptionPreferenceActivity.onClick");
//		this.OnClick();
		iPreferenceActivity.onClick();
	}
	
	public void OnClick() {
		super.onClick();
		System.out.println("ExceptionPreferenceActivity.OnClick");
	}

	public void onPreferenceChanged() {
		System.out.println("ExceptionPreferenceActivity.onPreferenceChanged");
//		this.OnPreferenceChanged();
		iPreferenceActivity.onPreferenceChanged();
	}
	
	public void OnPreferenceChanged() {
		super.onPreferenceChanged();
		System.out.println("ExceptionPreferenceActivity.OnPreferenceChanged");
	}
}
