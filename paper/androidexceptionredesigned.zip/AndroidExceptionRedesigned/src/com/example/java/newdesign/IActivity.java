package com.example.java.newdesign;

public interface IActivity {
	public void onCreate();
	public void onDestroy();
	public void onClick();
}
