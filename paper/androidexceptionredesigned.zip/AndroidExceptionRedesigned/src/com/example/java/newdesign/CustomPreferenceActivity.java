package com.example.java.newdesign;

public class CustomPreferenceActivity extends ExceptionPreferenceActivity {

	public void OnCreate() {
		super.OnCreate();
		System.out.println("CustomPreferenceActivity.OnCreate");
	}

	public void OnDestroy() {
		super.OnDestroy();
		System.out.println("CustomPreferenceActivity.OnDestroy");
	}

	public void OnClick() {
		super.OnClick();
		System.out.println("CustomPreferenceActivity.OnClick");
	}

	public void OnPreferenceChanged() {
		super.OnPreferenceChanged();
		System.out.println("CustomPreferenceActivity.OnPreferenceChanged");
	}

}
