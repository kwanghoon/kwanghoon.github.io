package com.example.java.newdesign;

public class ExceptionListActivity extends ListActivity implements IExceptionListActivity {
	private IListActivity iListActivity;
	public ExceptionListActivity() {
		this.iListActivity = new ExceptionListActivityCore(this);
	}
	
	public void onCreate() {
		System.out.println("ExceptionListActivity.onCreate");
//		this.OnCreate();
		iListActivity.onCreate();
	}
	
	public void OnCreate() {
		super.onCreate();
		System.out.println("ExceptionListActivity.OnCreate");
	}
	
	public void onDestroy() {
		System.out.println("ExceptionListActivity.onDestroy");
//		this.OnDestroy();
		iListActivity.onDestroy();
	}
	
	public void OnDestroy() {
		super.onDestroy();
		System.out.println("ExceptionListActivity.OnDestroy");
	}
	
	public void onClick() {
		System.out.println("ExceptionListActivity.onClick");
//		this.OnClick();
		iListActivity.onClick();
	}
	
	public void OnClick() {
		super.onClick();
		System.out.println("ExceptionListActivity.OnClick");
	}

	public void onItemClick() {
		System.out.println("ExceptionListActivity.onItemClick");
//		this.OnItemClick();
		iListActivity.onItemClick();
	}
	
	public void OnItemClick() {
		super.onItemClick();
		System.out.println("ExceptionListActivity.OnItemClick");
	}
}
