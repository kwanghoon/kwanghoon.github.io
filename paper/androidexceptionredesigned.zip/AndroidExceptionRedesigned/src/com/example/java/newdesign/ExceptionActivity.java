package com.example.java.newdesign;

public class ExceptionActivity extends Activity implements IExceptionActivity {
	IActivity iActivity;
	
	public ExceptionActivity() {
		this.iActivity = new ExceptionActivityCore(this);
	}
	
	public void onCreate() {
		System.out.println("ExceptionActivity.onCreate");
//		this.OnCreate();
		iActivity.onCreate();
	}
	
	public void OnCreate() {
		super.onCreate();
		System.out.println("ExceptionActivity.OnCreate");
	}
	
	public void onDestroy() {
		System.out.println("ExceptionActivity.onDestroy");
//		this.OnDestroy();
		iActivity.onDestroy();
	}
	
	public void OnDestroy() {
		super.onDestroy();
		System.out.println("ExceptionActivity.OnDestroy");
	}
	
	public void onClick() {
		System.out.println("ExceptionActivity.onClick");
//		this.OnClick();
		iActivity.onClick();		
	}
	
	public void OnClick() {
		super.onClick();
		System.out.println("ExceptionActivity.OnClick");
	}
}
