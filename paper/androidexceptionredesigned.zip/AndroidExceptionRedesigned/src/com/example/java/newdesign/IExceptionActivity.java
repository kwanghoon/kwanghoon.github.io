package com.example.java.newdesign;

public interface IExceptionActivity extends IActivity {
	public void OnCreate();
	public void OnDestroy();
	public void OnClick();
}
