package com.example.java.newdesign;

public interface IListActivity extends IActivity {
	public void onItemClick();
}
