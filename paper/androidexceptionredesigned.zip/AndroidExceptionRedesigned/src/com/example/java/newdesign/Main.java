package com.example.java.newdesign;

public class Main {

	public static void main(String[] args) {
		System.out.println("*** android classes ***");

		Activity activity = new Activity();
		ListActivity listActivity = new ListActivity();
		PreferenceActivity prefActivity = new PreferenceActivity();
		
		activity.onCreate();
		listActivity.onClick();
		prefActivity.onDestroy();
		
		System.out.println("*** exception classes ***");
		
		ExceptionActivity exnActivity = new ExceptionActivity();
		ExceptionListActivity exnListActivity = new ExceptionListActivity();
		ExceptionPreferenceActivity exnPrefActivity = new ExceptionPreferenceActivity();
		
		exnActivity.onCreate();
		exnListActivity.onCreate();
		exnPrefActivity.onCreate();
		
		System.out.println("*** custom classes ***");

		CustomActivity customActivity = new CustomActivity();
		CustomListActivity customListActivity = new CustomListActivity();
		CustomPreferenceActivity customPrefActivity = new CustomPreferenceActivity();
		
		customActivity.onCreate();
		
		System.out.println("");

		customListActivity.onCreate();
		customListActivity.onItemClick();
		
		System.out.println("");

		
		customPrefActivity.onCreate();
		customPrefActivity.onPreferenceChanged();
		
	}

}
