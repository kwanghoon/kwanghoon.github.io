package com.example.java.newdesign;

public class ExceptionActivityCore implements IActivity {
	private IExceptionActivity iExceptionActivity;
	public ExceptionActivityCore(IExceptionActivity iExceptionActivity) {
		this.iExceptionActivity = iExceptionActivity;
	}
	public void onCreate() {
		System.out.println("ExceptionActivityCore.onCreate");
		iExceptionActivity.OnCreate();
	}
	public void onDestroy() {
		System.out.println("ExceptionActivityCore.onDestroy");
		iExceptionActivity.OnDestroy();
	}
	public void onClick() {
		System.out.println("ExceptionActivityCore.onClick");
		iExceptionActivity.OnClick();
	}
}
