package com.example.java.newdesign;

public class ExceptionPreferenceActivityCore extends ExceptionActivityCore
	implements IPreferenceActivity {
	
	private IExceptionPreferenceActivity iExceptionPreferenceActivity;
	
	public ExceptionPreferenceActivityCore(IExceptionPreferenceActivity iExceptionPreferenceActivity) {
		super(iExceptionPreferenceActivity);
		this.iExceptionPreferenceActivity = iExceptionPreferenceActivity;
	}
	public void onPreferenceChanged() {
		System.out.println("ExceptionPreferenceActivityCore.onPreferenceChanged");
		iExceptionPreferenceActivity.OnPreferenceChanged();
	}
}
