package com.example.java.newdesign;

public class CustomListActivity extends ExceptionListActivity {

	public void OnCreate() {
		super.OnCreate();
		System.out.println("CustomListActivity.OnCreate");
	}

	public void OnDestroy() {
		super.OnDestroy();
		System.out.println("CustomListActivity.OnDestroy");
	}

	public void OnClick() {
		super.OnClick();
		System.out.println("CustomListActivity.OnClick");
	}

	public void OnItemClick() {
		super.OnItemClick();
		System.out.println("CustomListActivity.OnItemClick");
	}

}
