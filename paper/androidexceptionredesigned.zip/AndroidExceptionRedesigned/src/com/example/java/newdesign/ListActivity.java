package com.example.java.newdesign;

public class ListActivity extends Activity {
	public void onCreate() {
		super.onCreate();
		System.out.println("ListActivity.onCreate");
	}
	public void onDestroy() {
		super.onDestroy();
		System.out.println("ListActivity.onDestroy");
	}
	public void onClick() {
		super.onClick();
		System.out.println("ListActivity.onClick");
	}
	
	public void onItemClick() {
		System.out.println("ListActivity.onItemClick");
	}
	
	public void setAdapter() {
		System.out.println("ListActivity.setAdapter");
	}
}
