package com.example.java.newdesign;

public interface IExceptionListActivity extends IListActivity, IExceptionActivity {
	public void OnItemClick();
}
