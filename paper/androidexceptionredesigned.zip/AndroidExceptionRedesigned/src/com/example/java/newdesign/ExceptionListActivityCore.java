package com.example.java.newdesign;

public class ExceptionListActivityCore extends ExceptionActivityCore 
	implements IListActivity {
	
	private IExceptionListActivity iExceptionListActivity;
	
	public ExceptionListActivityCore(IExceptionListActivity iExceptionListActivity) {
		super(iExceptionListActivity);
		this.iExceptionListActivity = iExceptionListActivity;
	}
	public void onItemClick() {
		System.out.println("ExceptionListActivityCore.onItemClick");
		iExceptionListActivity.OnItemClick();
	}
}
