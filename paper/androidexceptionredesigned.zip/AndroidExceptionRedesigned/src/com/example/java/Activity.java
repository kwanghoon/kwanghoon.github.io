package com.example.java;

public class Activity {
	public void onCreate() {
		System.out.println("Activity.onCreate");
	}
	public void onDestroy() {
		System.out.println("Activity.onDestroy");
	}
	public void onClick() {
		System.out.println("Activity.onClick");
	}
}
