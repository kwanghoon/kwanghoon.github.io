package com.example.java;

public class ExceptionPreferenceActivity extends PreferenceActivity {
	public void onCreate() {
		System.out.println("ExceptionPreferenceActivity.onCreate");
		this.OnCreate();
	}
	
	public void OnCreate() {
		super.onCreate();
		System.out.println("ExceptionPreferenceActivity.OnCreate");
	}
	
	public void onDestroy() {
		System.out.println("ExceptionPreferenceActivity.onDestroy");
		this.OnDestroy();
	}
	
	public void OnDestroy() {
		super.onDestroy();
		System.out.println("ExceptionPreferenceActivity.OnDestroy");
	}
	
	public void onClick() {
		System.out.println("ExceptionPreferenceActivity.onClick");
		this.OnClick();
	}
	
	public void OnClick() {
		super.onClick();
		System.out.println("ExceptionPreferenceActivity.OnClick");
	}

	public void onPreferenceChanged() {
		System.out.println("ExceptionPreferenceActivity.onPreferenceChanged");
		this.OnPreferenceChanged();
	}
	
	public void OnPreferenceChanged() {
		super.onPreferenceChanged();
		System.out.println("ExceptionPreferenceActivity.OnPreferenceChanged");
	}
}
