package com.example.java;

public class CustomPreferenceActivity extends ExceptionPreferenceActivity {

	public void OnCreate() {
		super.OnCreate();
		System.out.println("CustomActivity.OnCreate");
	}

	public void OnDestroy() {
		super.OnDestroy();
		System.out.println("CustomActivity.OnDestroy");
	}

	public void OnClick() {
		super.OnClick();
		System.out.println("CustomActivity.OnClick");
	}

	public void OnPreferenceChanged() {
		super.OnPreferenceChanged();
		System.out.println("CustomActivity.OnPreferenceChanged");
	}

}
