package com.example.java;

public class ExceptionActivity extends Activity {
	public void onCreate() {
		System.out.println("ExceptionActivity.onCreate");
		this.OnCreate();
	}
	
	public void OnCreate() {
		super.onCreate();
		System.out.println("ExceptionActivity.OnCreate");
	}
	
	public void onDestroy() {
		System.out.println("ExceptionActivity.onDestroy");
		this.OnDestroy();
	}
	
	public void OnDestroy() {
		super.onDestroy();
		System.out.println("ExceptionActivity.OnDestroy");
	}
	
	public void onClick() {
		System.out.println("ExceptionActivity.onClick");
		this.OnClick();
	}
	
	public void OnClick() {
		super.onClick();
		System.out.println("ExceptionActivity.OnClick");
	}
}
